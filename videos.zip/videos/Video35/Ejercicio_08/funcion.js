function Patron(texto, tron) {
    let re = new RegExp(tron, 'g');
    let resul = texto.replace(re, "");
    resultado = resul.replace(/\s+/g, " ").trim();
    return resultado;
}

let resul = Patron("xyz1, xyz2, xyz3, xyz4 xyz5", "xyz");
console.log(resul);
