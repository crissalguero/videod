function Palindromo(texto){
    let limpio = texto.replace(/[^a-zA-Z]/g, "").toLowerCase();
    let textoReves = limpio.split("").reverse().join("");
   return limpio == textoReves;
}

console.log(Palindromo("salas"))