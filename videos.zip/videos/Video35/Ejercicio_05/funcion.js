function Invertir(cadena){
    let palabras = cadena.split(" ");
    let PalabraInvertir = palabras.map(palabra => palabra.split("").reverse().join(""));
    let cadenaInv = PalabraInvertir.join(" ");
    return cadenaInv;
}

let resutado = Invertir("Hola Mundo");
console.log(resutado);