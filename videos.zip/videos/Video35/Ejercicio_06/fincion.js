function Contar(texto,pala){
    let palabra = texto.split(" ");
    let contador = 0;
    for (let i = 0; i<palabra.length; i++){
        if(palabra[i] === pala){
            contador++;
        }
    }

    return contador;
}

let resul = Contar("Hola mundo adios mundo", "mundo");
console.log(resul);

