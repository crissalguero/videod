function contarCaracteres (input){
    let texto = input.toString();
    return texto.length;
  
}

let texto1 = "hola mundo";
let numero= contarCaracteres(texto1);
console.log("Numero de caracteres:" + numero);

let numero1 = 123456;
console.log("Numero de caracteres: "+numero1);