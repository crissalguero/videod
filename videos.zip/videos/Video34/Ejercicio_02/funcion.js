function Recortar(texto, numeroCaracteres){
    return texto.slice(0,numeroCaracteres);
}

let texto = "Hola Mundo";
let recortar = Recortar(texto,6);
console.log(recortar)