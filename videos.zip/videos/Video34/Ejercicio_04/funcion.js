function RepetirX(texto, num){
    return texto.repeat(num);
}

let texto = "hola Mundo";
let resultado = RepetirX(texto,5);
console.log(resultado);