function ArrayTexto(texto, separador){
    return texto.split(separador);
}

let texto = "Hola Que Tal";
let resultado = ArrayTexto(texto,"");
console.log(resultado);